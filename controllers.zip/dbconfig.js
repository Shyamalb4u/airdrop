const { prototype } = require("jsonwebtoken/lib/JsonWebTokenError");

const config = {
  user: "ibsair1247", // Database username
  password: "IIb85sdata*aI", // Database password
  server: "103.69.196.69", // Server IP address
  database: "airibsdrop", // Database name
  options: {
    encrypt: false, // Disable encryption
  },
  port: 1533,
};

module.exports = config;
